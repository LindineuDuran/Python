#import myModule
from myModule import *

r = float(input('Please enter radius:'))

print('The circumference of the circle with radius', r, 'is', circumference(r))
print('The area of the circle with radius', r, 'is', area(r))