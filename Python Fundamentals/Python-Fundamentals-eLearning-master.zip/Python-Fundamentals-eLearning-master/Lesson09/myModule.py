import math


def circumference(radius):
    return 2 * math.pi * radius


def area(radius):
    return math.pi * radius ** 2
