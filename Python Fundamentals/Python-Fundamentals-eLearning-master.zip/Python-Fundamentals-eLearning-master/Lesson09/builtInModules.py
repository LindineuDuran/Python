# import 2 modules turtle and time
import turtle, time

# reference the documentation from both modules
print(help(time))

turtle.speed(1)
for i in range(0,4):
    turtle.forward(200)
    turtle.right(90)
time.sleep(10)

# draw a shape and have it remain on the screen

