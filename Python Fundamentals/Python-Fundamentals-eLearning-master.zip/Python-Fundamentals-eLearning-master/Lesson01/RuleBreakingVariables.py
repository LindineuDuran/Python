dollars ='lots of money'
pass_word = 'Eureka'
my_items = ['bag', 'racket', 'watch']
ten_thousand = 10000
IMPORT = 'bringing goods into the country'
Tupac = 'All Eyez on Me'

print('Yay error free')
