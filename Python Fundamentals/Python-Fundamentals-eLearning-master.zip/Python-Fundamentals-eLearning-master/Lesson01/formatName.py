import sys

print('------------------------')
print('First Name:',sys.argv[1])
print('Last Name:',sys.argv[2])
print('------------------------')