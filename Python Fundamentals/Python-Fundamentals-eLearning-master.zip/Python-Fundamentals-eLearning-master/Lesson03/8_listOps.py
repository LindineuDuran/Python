my_friends = ['Sally', 'Bob', 'Clare']
your_friends = ['Jack', 'Jill', 'Luke']

print(my_friends+your_friends)

my_friends += your_friends

people = list(my_friends)

my_friends[4] = 'Jane'

print(my_friends)
print(people)