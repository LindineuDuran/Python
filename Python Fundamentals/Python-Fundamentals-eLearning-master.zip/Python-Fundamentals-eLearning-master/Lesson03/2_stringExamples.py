a = 'Merry'
b = 'Christmas'

message = a + ' ' + b

print(message)

message = message + '!'
message += '!'

print(message)

long_message = message*5
print(long_message)