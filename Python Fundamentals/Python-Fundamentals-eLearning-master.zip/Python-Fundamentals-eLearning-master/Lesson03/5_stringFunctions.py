text = '''
Python is an interpreted, high-level, general-purpose programming language. Created by Guido van Rossum and first 
released in 1991, Python has a design philosophy that emphasizes code readability, notably using significant whitespace. 
It provides constructs that enable clear programming on both small and large scales. In July 2018, Van Rossum 
stepped down as the leader in the language community.
'''

# text.capitalize()
# text.lower()
# text.upper()
# text.startswith()
# text.endswith()
# text.strip('.')
# text = text.replace('a','@')
# text = text.replace('l','1')
# text.split(',')
# text.split()
print(text.count('t'))
