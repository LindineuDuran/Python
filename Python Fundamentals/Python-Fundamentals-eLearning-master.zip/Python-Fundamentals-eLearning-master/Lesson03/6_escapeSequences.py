sonnet = 'When forty winters "shall" beseige thy brow, And dig deep trenches in thy beauty\'s field, Thy youth\'s proud livery, so gazed on now, Will be a tatter\'d weed, of small worth held'

print(sonnet)
