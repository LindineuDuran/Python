num = 33

print(bin(num))
print(oct(num))
print(hex(num))
print(float(num))

# example hex colour DC 14 3C

r = int('DC', 16)
g = int('14', 16)
b = int('3C', 16)

print(r, g, b)
