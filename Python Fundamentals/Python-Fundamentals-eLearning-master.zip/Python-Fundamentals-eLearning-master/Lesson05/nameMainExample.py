def summation(first, second):
    total = first + second
    return total


def main():
    print('the sum is', summation(10, 20))



if __name__ == "__main__":
    main()
