name = input('what is your name:')

if name == 'Bob':
    print('Hey Bob how are you doing?')
elif name == 'Alice':
    print('Hey Alice nice to see you')
elif name == 'Sally':
    print('Happy Birthday Sally')
else:
    print('I dont know you',name,'go away?')
