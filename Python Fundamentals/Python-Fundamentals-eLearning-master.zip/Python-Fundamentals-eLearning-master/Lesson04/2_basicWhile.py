current = 1
end = 10

while current <= end:
    print(current)
    #current += 1
    current *= 1.06

print('you have reached the end')
