coordinates = []

for x in range(0, 5):
    for y in range(0, 5):
        c = str(x) + ',' + str(y)
        coordinates.append(c)

print(coordinates)