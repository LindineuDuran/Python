num = int(input('Provide a number here:'))
print('here is a times table for', num)

for i in range(1, 11):
    print(i * num)
