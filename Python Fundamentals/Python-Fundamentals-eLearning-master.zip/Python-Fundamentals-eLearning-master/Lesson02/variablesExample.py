height = 18
radius = 33

volume = 3.14 * radius * radius * height
surface_area = (2 * 3.14 * radius * height) + (2 * 3.14 * radius * radius)

print('a cylinder with height',height,'and radius',radius,'has a volume of',volume)
print('a cylinder with height',height,'and radius',radius,'has a surface area of',surface_area)

# edit print statement to say something like this:
# a cylinder with height 20 and radius 10 has volume of 6280
# 2πrh+2πr2