numbers = [1, 2, 3, 4, 5, 6, 7, 8]
letters = ['a', 'b', 'c', 'd']
'''
list.append(item)
list.extend(iterable)
list.insert(index, item)
list.remove(item)
list.pop([index])
list.clear()
list.index(item [, start [, end]])
list.count(item)
list.sort(key=None, reverse=False)
list.reverse()
list.copy()
'''
