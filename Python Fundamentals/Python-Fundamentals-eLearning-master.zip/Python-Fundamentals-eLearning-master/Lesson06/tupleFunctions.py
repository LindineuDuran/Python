pets = ('cat', 'dog', 'horse')
numbers = (5, 4, 3, 2, 1)
aliens = (0, False)

# any()
print(any(pets))
print(any(numbers))
print(any(aliens))

# .count()
print(numbers.count(5))
print(numbers.count(6))

# min()
print(min(pets))
print(min(numbers))

# max()
print(max(numbers))

# len()
print(len(aliens))
print(len(pets))
