
print(any(a))
