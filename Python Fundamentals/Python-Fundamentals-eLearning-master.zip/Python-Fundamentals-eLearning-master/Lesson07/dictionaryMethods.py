letters = ['a', 'b', 'c', 'd', 'e']

scores = {
    'Bob': 20,
    'Alice': 23,
    'Jim': 22,
}
'''
dict.copy()
dict.update()
dict.keys()  # lets you know what to query
keys = dict.fromkeys(list)
scores.get('key')
min() max() and len()
dict.pop()
dict.popitem())
dict.clear()
'''