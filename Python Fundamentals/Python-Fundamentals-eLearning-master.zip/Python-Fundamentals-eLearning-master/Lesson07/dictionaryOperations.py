scores = {
    'Bob': 20,
    'Alice': 23,
    'Jim': 22,
    'Xavier': 0
}
print('Bob' in scores)
scores['Bob'] += 1

print(scores)
