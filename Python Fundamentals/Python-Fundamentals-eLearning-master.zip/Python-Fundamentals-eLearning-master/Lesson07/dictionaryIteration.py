scores = {
    'Bob': 20,
    'Alice': 23,
    'Jim': 22,
    'Xavier': 0
}

for name in scores:
    print('The score of',name,'is',scores[name])
