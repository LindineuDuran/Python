#!/bin/bash

docker build -t cr-api-indicadores .
docker tag cr-api-indicadores  southamerica-east1-docker.pkg.dev/vtal-apiviabilidade-prd/gcr-artifact-data-analytics/cr-api-indicadores
docker push southamerica-east1-docker.pkg.dev/vtal-apiviabilidade-prd/gcr-artifact-data-analytics/cr-api-indicadores
gcloud run deploy cr-api-indicadores --image=southamerica-east1-docker.pkg.dev/vtal-apiviabilidade-prd/gcr-artifact-data-analytics/cr-api-indicadores --region=southamerica-east1
gcloud run services describe cr-api-indicadores  --region=southamerica-east1
