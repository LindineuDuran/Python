#!/bin/bash

rm -f *.bak
gcloud run services replace cr-api-indicadores_service.yaml
gcloud run services describe cr-api-indicadores --region=southamerica-east1  --format export > cr-api-indicadores_service_new.yaml 

