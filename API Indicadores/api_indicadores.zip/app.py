##############################################################################################################
# Nome do Objeto: app.py
# Tipo: APP ENGINE
# Propósito: API Indicadores - Retorna todos os indicadores da tenant com historico de 12 meses
# Autor: Marcelo Ambrosio e Gustavo Pereira
# Data de Criação: 06/08/2024
# Processo Relacionado: Portal Operacional / BI Indicadores de Performance
# Notas Adicionais: N/A
##############################################################################################################
# Histórico de Alterações:
# 06/08/2024: Versão 0.1 - Marcelo Ambrosio - Prototipo
# 02/09/2024: Versão 1.0 - Gustavo Pereira - US107864 - Versao Inicial
##############################################################################################################

from flask import Flask, request, jsonify
import os
from datetime import datetime
from psycopg2.extras import RealDictCursor
from psycopg2.pool import SimpleConnectionPool
from google.cloud import secretmanager

def get_secret(project_id: str, secret_id: str):
  """
     Busca uma Secrect ID no Google Secret Manager do projeto apiviabilidade-prd
  """
  client = secretmanager.SecretManagerServiceClient()
  name = f"projects/{project_id}/secrets/{secret_id}/versions/latest"
  response = client.access_secret_version(name=name)
  return response.payload.data.decode('UTF-8')

def busca_indicadores(param_tenant: str, param_anomes: str):
    try:
        # Obter uma conexão do pool
        conn = connection_pool.getconn()

        cursor = conn.cursor(cursor_factory=RealDictCursor)
        query = f"""
                    SELECT
                    mes,
                    indicador,
                    qtd
                    from bi.tb_ind_performance_looker_to_pcw
                    where upper(cd_company_hc) = upper(%(tenant)s)
                    and mes > (date_trunc('month', %(data)s) - interval '12 month')
                    and mes <= date_trunc('month', %(data)s)
                    order by 2,1
                """
        # Executar a consulta
        cursor.execute(query, {'tenant':param_tenant, 'data':datetime.strptime(param_anomes, '%Y%m%d')})
        rows = cursor.fetchall()

        # Se não houve retorno da consulta, retorna 404
        if len(rows) == 0:
            resp = { "404": f'Indicadores não encontrados para a tenant:[{param_tenant}] e data:[{param_anomes}]' }
            return resp

        # Processando o resultado
        result = {'tenant' : param_tenant}
        indicadores = []
        indicador = {'indicador' : ''}
        dados = []
        for row in rows:
            if indicador['indicador'] != row['indicador']:
                if indicador['indicador']:
                    indicador['dados'] = dados
                    indicadores.append(indicador)
                    dados = []
                    indicador = {}
                indicador['indicador'] = row['indicador']
            dados.append({'data' : row['mes'].strftime("%Y-%m-%d"), 'qtd' : float(row['qtd'])})
        result['indicadores'] = indicadores

        return {'result' : result}
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        # Fechar o cursor e devolver a conexão ao pool
        cursor.close()
        connection_pool.putconn(conn)

#
# Recupera do Secret Manager informacoes para conexao no banco
#
API_PROJECT=os.environ['API_PROJECT']
os.environ['DB_HOST']=get_secret(API_PROJECT,"da-prod-db-host")
os.environ['DB_NAME']=get_secret(API_PROJECT,"da-prod-db-name")
os.environ['DB_USER']=get_secret(API_PROJECT,"da-prod-db-user-name")
os.environ['DB_PWD']=get_secret(API_PROJECT,"da-prod-db-user-password")
# Limpo a variavel do projeto
API_PROJECT=""

# Criar um pool de conexões
connection_pool = SimpleConnectionPool(2, 15, user=os.environ['DB_USER'],
                                        password=os.environ['DB_PWD'],
                                        host=os.environ['DB_HOST'],
                                        database=os.environ['DB_NAME'])

app = Flask(__name__)
app.json.sort_keys = False

@app.route("/", methods=["GET"])
def inicio():
  service = os.environ.get('K_SERVICE', 'Serviço desconhecido')
  revision = os.environ.get('K_REVISION', 'Revisão desconhecida')
  final = {  "service": f"{service}",
             "revision": f"{revision}"
        }
  return jsonify(final), 200

@app.route("/v1/busca_indicadores", methods=["GET"])
def get_indicadores_endpoint():
    """
    API Indicadores       : busca_indicadores
    Parametros de entrada : tenant, data
    Retorno               : indicadores

    http exceptions:
        200 - 'OK'
        400 - 'Problema na requisição. Parâmetro faltando: [tenant]'
        400 - 'Problema na requisição. Parâmetro faltando: [data]'
        400 - 'Problema na requisição. Data inválida'
        401 - 'Não autorizado'
        404 - 'Indicadores não encontrados'
        500 - 'Erro Genérico - Erro não esperado'
    """
    #
    # Buscar Parametros
    #
    args = request.args
    try:
        param_tenant = args.get('tenant', default=None, type=None)
        param_anomes = args.get('data', default=None, type=None)
    except Exception as e:
        # Retorna erro generico em caso de qualquer problema
        return jsonify(str(e)), 500

    if  ( param_tenant == None ):
        return jsonify(f"Problema na requisição. Parâmetro faltando: [tenant]"), 400
    if  ( param_anomes == None ):
        return jsonify(f"Problema na requisição. Parâmetro faltando: [data]"), 400

    # Testando a data informada

    try:
        newDate = datetime.strptime(param_anomes, '%Y%m%d')
    except ValueError:
        return jsonify(f"Problema na requisição. Data [{param_anomes}] é inválida."), 400
    
    final = busca_indicadores(param_tenant, param_anomes)

    for x in final:
        if x == "result":
            return jsonify(final), 200
        if x == "404":
            return jsonify(final["404"]), 404
        if x == "500":
            return jsonify(final["500"]), 500

if __name__ == '__main__':
    app.run(debug=False)
