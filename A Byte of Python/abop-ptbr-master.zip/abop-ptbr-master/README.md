# A Byte of Python (pt-br)

Tradução do livro [A Byte of Python](http://www.swaroopch.com/notes/Python) para o português brasileiro.

## Sobre o livro

Voltado para iniciantes, o livro [A Byte of Python](http://www.swaroopch.com/notes/Python) foi escrito por [Swaroop C. H.](http://swaroopch.com/) Sua finalidade é ser um tutorial para pessoas que têm vontade de aprender a programar mas ainda não conhecem nenhuma linguagem. Segundo o autor, "se tudo o que você sabe sobre computadores é como salvar arquivos de texto, então este livro é para você".

## Sobre a tradução

A [edição traduzida](http://swaroopch.com/notes/Python_pt-br:Indice) contempla as mudanças trazidas pela versão 3.x de Python. Ao redor do mundo, várias pessoas se ofereceram como voluntárias para traduzir o livro para seus respectivos idiomas. A versão em português brasileiro ficou sob minha responsabilidade e logo comecei a receber vários emails de pessoas que também se ofereceram para ajudar, de forma que, num pequeno intervalo de tempo, já tínhamos quase todo o texto traduzido. Portanto, gostaria de agradecer às seguintes pessoas pela prestatividade e disposição:

- Alvaro Netto
- Daniel Bagatini
- Daniel Gonçalves
- David Kwast
- Emanuel R Woiski
- Estêvão Valadão
- Éverton Arruda
- Lucas Castro
- Naner Nunes
- Rodrigo Haas
 






